package assignment1;


import java.util.*;


public class Sum_evennum_array {
	
	void arraysum(){
		int sum=0;
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the size of array: ");
		int n = sc.nextInt();
		int arr[] = new int[n];
		System.out.print("Enter the "+n+ " values: ");
		for(int i = 0; i<n; i++) {
			arr[i]=sc.nextInt();
			sum+=arr[i];
		}
		System.out.println("Sum of the entered values are: "+sum);
	}


	public static void main(String args[]) {
		
		Sum_evennum_array as = new Sum_evennum_array();
		
		
	}


}
