import java.util.Scanner;

public class Vowel_count {
static String inp;

	
	public static void main(String[] args) {
//		Scanner scan=new Scanner(System.in);
		// TODO Auto-generated method stub
//System.out.println("enter the string ::");
//String inp=scan.nextLine();
//int in=inp.length();
Vowel_count.display();
	}
static void display() {
	Scanner scan=new Scanner(System.in);
	System.out.println("enter the string ::");
	String inp=scan.nextLine();
	int in=inp.length();
	int inpA=0,inpE=0,inpI=0,inpO=0,inpU=0;
	for (int i=0;i<in;i++) {
		if(inp.charAt(i)=='a') {
			;
			 inpA=inpA+1;
		}
		if(inp.charAt(i)=='e') {
			
			 inpE=inpE+1;
		}
		if(inp.charAt(i)=='i') {
			
			 inpI=inpI+1;
		}
		if(inp.charAt(i)=='o') {
		
			 inpO=inpO+1;
		}
		if(inp.charAt(i)=='u') {
			
			 inpU=inpU+1;
	}
//		System.out.println("occuerence of a is "+inpA);
//		System.out.println("occuerence of e is "+inpE);
//		System.out.println("occuerence of i is "+inpI);
//		System.out.println("occuerence of o is "+inpO);
//		System.out.println("occuerence of u is "+inpU);
}
	System.out.println("occuerence of a is "+inpA);
	System.out.println("occuerence of e is "+inpE);
	System.out.println("occuerence of i is "+inpI);
	System.out.println("occuerence of o is "+inpO);
	System.out.println("occuerence of u is "+inpU);
}
}
