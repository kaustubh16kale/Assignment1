package assignment1;


import java.util.*;


public class SumOfTwoInt {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter any two int number to convert to double type ");
		int n1 = sc.nextInt();
		int n2 = sc.nextInt();
		double sum = (double)n1+n2;
		System.out.println("Sum is: "+sum);
	}


}
