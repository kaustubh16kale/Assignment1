package assignment1;

import java.util.Scanner;
public class Q2 {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("enter the string\n");
		String input;
		input=scan.nextLine();
		String s1 = input;
		String s2 = "";
		for (int i=(s1.length()-1); i>=0;i--) {		
			char ch;
		ch=s1.charAt(i);
		s2=s2+ch;	
		}
		System.out.println(s2);
		
	}
}
