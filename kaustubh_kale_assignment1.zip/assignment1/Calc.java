package assignment1;


import java.util.*;


public class Calc {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter any two numbers to perform operation ");
		float n1 = sc.nextFloat();
		float n2 = sc.nextFloat();
		System.out.println("Addition of the two numbers is: "+ (n1+n2));
		System.out.println("\nSubtraction of the two numbers is: "+ (n1-n2));
		System.out.println("\nMultiplication of the two numbers is: "+ (n1*n2));
		System.out.println("\nDivision of the two numbers is: "+ (n1/n2));


	}


}
