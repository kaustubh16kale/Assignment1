package assignment1;


import java.util.*;


public class AreaOfRect {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the length and breadth of the rectangle: ");
		float l=sc.nextFloat();
		float b=sc.nextFloat();
		float area = l*b;
		System.out.println("Area of the rectangle is: " +area);
	}


}
