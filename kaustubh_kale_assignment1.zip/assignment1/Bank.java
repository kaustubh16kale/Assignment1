package assignment1;
import java.util.Scanner;
import java.util.* ;

/*public class bankclass {

		int bank_num;
		int balance=1000;
		String acc_holder;

//public int getA() {
//	
//}
		public int getA() {
			return this.balance=balance;
		}
		public int  setA() {
			return this.balance=balance;
		}
	public static void main(String[] args) {


//System.out.println(bankclass.bankinp(balance));
bankclass deposit= new bankclass();
bankclass withdraw = new bankclass();
bankclass.deposit(0);
	}
	public static int deposit(int balance) {

		Scanner scan=new Scanner(System.in);
		System.out.println("enter the amount to be added:");
		int paisa = scan.nextInt();
		balance=balance+paisa;
		System.out.println(balance);
		return balance;

	}
	public static int withdraw(int balance) {
		Scanner scan=new Scanner(System.in);
		System.out.println("enter the amount to be withdraw:");
		int paisa=scan.nextInt();
		balance = balance-paisa;
		return balance;
	}

}
 */

public class Bank {
	int bank_num;
	static int balance=90;
	String acc_holder;
	public static void main(String[] args) {
		Bank.sw();
	}
	public static void sw() {
		Scanner scanner=new Scanner(System.in);
		System.out.println("1) for deposit");
		System.out.println("2) for withdraw:");
		int inp =scanner.nextInt();
		switch(inp) {
		case 1: 
			Bank.deposit();
			break;
		case 2:
			Bank.withdraw();
		}
	}
	public static void deposit() {
		Scanner scan=new Scanner(System.in);
		System.out.println("enter the amount to be deposited::");
		int paisa=scan.nextInt();
		balance=balance+paisa;
		Bank.viewbal();


	}
	public static void withdraw() {
		Scanner scan=new Scanner(System.in);
		System.out.println("enter the amount to be withdraw::");
		int paisa=scan.nextInt();
		balance=balance-paisa;
		Bank.viewbal();


	}
	public static void viewbal() {
		System.out.println("the updated balance is::"+balance);
	}
}