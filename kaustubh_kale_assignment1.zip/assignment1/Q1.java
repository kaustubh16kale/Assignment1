package assignment1;

import java.util.Scanner;


public class Q1 {
	
	public static int area_rect(int l, int b){
		int arect=l*b;
		return arect;
	}

	public static float area_tri(int b, int h) {
		float f=0.5f;
		float atri=f*b*h;
		return atri;
	}
	
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		
		
		
		System.out.println("1) for area of rectangle");
		System.out.println("2) for area of triangle");
		int inp1=scan.nextInt();
		switch (inp1){
		case 1:
			System.out.println("Area of rectangle is: " +Q1.area_rect(5, 7));
			break;
		case 2:
			System.out.println("Area of triangle is: " +Q1.area_tri(6, 5));
			
			
			
		}

	}

}