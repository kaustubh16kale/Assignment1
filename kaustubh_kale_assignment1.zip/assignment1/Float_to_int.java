package assignment1;


import java.util.*;


public class Float_to_int {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the value in float: ");
		float a = sc.nextFloat();
		System.out.println("Enter the value in int: ");
		int b = sc.nextInt();
		int check = (int)a;
		float check1 = (float)b;
		System.out.println("Conversion from int to float: "+check);
		System.out.println("Conversion from float to int: "+check1);		
	}


}
