package assignment1;
import java.util.Scanner;

public class Password_check{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int check1;
		Scanner scan=new Scanner(System.in);
		System.out.println("enter the password");
		int check=scan.nextInt();
		do {
			System.out.println("enter the password again");
			check1=scan.nextInt();
		} while (check!=check1);
		System.out.println("correct password");
	}


}
