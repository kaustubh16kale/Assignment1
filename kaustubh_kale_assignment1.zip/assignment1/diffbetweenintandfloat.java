package assignment1;


import java.util.*;


public class diffbetweenintandfloat {
    public static void main(String[] args) {
    	 // String concatenation
        String firstName = "Charlie";
        String lastName = "Kale";
        String fullName = firstName + " " + lastName;
        
        System.out.println("\nString Concatenation:");
        System.out.println("Full Name: " + fullName);
    	
    	// Integer arithmetic
        int num1 = 56;
        int num2 = 25;
        int sum = num1 + num2;
        int difference = num1 - num2;
        
        System.out.println("Integer Arithmetic:");
        System.out.println("Sum: " + sum);
        System.out.println("Difference: " + difference);


        // Double arithmetic
        double doubleNum1 = 22.5;
        double doubleNum2 = 31.5;
        double product = doubleNum1 * doubleNum2;
        double quotient = doubleNum1 / doubleNum2;
        
        System.out.println("\nDouble Arithmetic:");
        System.out.println("Product: " + product);
        System.out.println("Quotient: " + quotient);


       
    }
}
