package assignment1;


import java.util.*;


public class Areaofcirlce_volumeofsphere {
	
	public static float Area_circle(float r){
	    float area = 3.14f*r*r;
	    System.out.println("Area of circle is: "+area);
		return area;
	}
	
	public static float Volume_sphere(float r) {
		float volume = (4*3.14f*r*r*r)/3 ;
		System.out.println("Volume of the circle is: "+volume);
		return volume;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the radius: ");
		float rad = sc.nextFloat();
		System.out.println("Enter your choice: ");
		System.out.println("1) Area of the circle");
		System.out.println("2) Volume of the circle");
		int c = sc.nextInt();
		switch(c) {
		case 1: 
			Area_circle(rad);
			break;
		case 2:
			Volume_sphere(rad);
			break;
		}
	}
	
}
