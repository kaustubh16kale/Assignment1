package assignment1;

import java.util.Scanner;

public class Fahrenheit_Celsius {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner scan=new Scanner(System.in);
System.out.println("1)Fahrenheit to celsius");
System.out.println("2) celsius to Fahrenheit");
int x=scan.nextInt();
Fahrenheit_Celsius.sww(x);
	}
public static void sww(int x) {
	Scanner scan= new Scanner(System.in);
	switch(x) {
	case 1: 
		System.out.println("enter the Fahrenheeit :");
		int f=scan.nextInt();
		double C = (f-32)*0.555555555;
		System.out.println(C);
		break;
	case 2:
		System.out.println("enter the celsius:");
		int cel=scan.nextInt();
		double celll=(((cel*9)/5)+32);
		System.out.println(celll);
		
	}
}
}
